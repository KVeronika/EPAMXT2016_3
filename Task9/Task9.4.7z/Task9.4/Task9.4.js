/**
 * Created by Veronika on 11/29/2016.
 */
(function () {
    var pages = ['/Task9.4/Index.html', '/Task9.4/Page2.html', '/Task9.4/Page3.html'];
    setTimeout(function run() {
        goToNextPage();
        setTimeout(run, 500);
    }, 500);

    function goToNextPage() {
        var i;
        for(i = 0; i < pages.length; i++){
            if(window.location.pathname === pages[pages.length - 1]){
                alert('This is the end');
                return;
            }
            if(pages[i] === window.location.pathname){
                window.location.replace(pages[++i]);
                return;
            }
        }
    }
})();